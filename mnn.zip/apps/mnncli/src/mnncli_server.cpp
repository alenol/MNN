//
// Created by ruoyi.sjd on 2024/12/25.
// Copyright (c) 2024 Alibaba Group Holding Limited All rights reserved.
//
// Modified 2026: local knowledge base (RAG) toggle, document upload, and
// image (multimodal) upload support for the MNN LLM chat server.
//

#include "mnncli_server.hpp"
#include "llm/reranker.hpp"
#include "log_utils.hpp"
#include <iostream>
#include <sstream>
#include <fstream>
#include <cctype>
#include <algorithm>
#include <atomic>
#include <ctime>
#include <filesystem>
#include <regex>

// MNN::CV::imread (tools/cv/imgcodecs) is compiled into libMNN only when it is
// built with MNN_BUILD_LLM_OMNI=ON (required for vision models). When the
// symbol is present, MNN_IMGCODECS is defined by the cv module's build.
#ifdef MNN_IMGCODECS
#include <cv/imgcodecs.hpp>
#endif

namespace fs = std::filesystem;

namespace mnncli {

std::string GetCurrentTimeAsString() {
  auto now = std::chrono::system_clock::now();
  auto duration = now.time_since_epoch();
  auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration).count();
  return std::to_string(seconds);
}

bool FromJson(const json& j, PromptItem& item) {
  if (!j.is_object()) return false;
  if (!j.contains("role") || !j["role"].is_string()) return false;
  if (!j.contains("content") || !j["content"].is_string()) return false;
  item.first = j["role"].get<std::string>();
  item.second = j["content"].get<std::string>();
  return true;
}

std::string trimLeadingWhitespace(const std::string& str) {
    auto it = std::find_if(str.begin(), str.end(), [](unsigned char ch) {
        return !std::isspace(ch);
    });
    return std::string(it, str.end());
}

std::string ExtractAnthropicText(const json& content) {
    if (content.is_string()) return content.get<std::string>();
    if (content.is_object()) {
        if (content.contains("type") && content["type"].is_string() &&
            content["type"].get<std::string>() == "text" &&
            content.contains("text") && content["text"].is_string()) {
            return content["text"].get<std::string>();
        }
        return "";
    }
    if (content.is_array()) {
        std::string merged;
        bool first = true;
        for (const auto& block : content) {
            auto text = ExtractAnthropicText(block);
            if (text.empty()) continue;
            if (!first) merged += "\n";
            merged += text;
            first = false;
        }
        return merged;
    }
    return "";
}

json BuildOpenAiMessagesFromAnthropicRequest(const json& request_json) {
    json messages = json::array();
    if (request_json.contains("system")) {
        auto system_text = ExtractAnthropicText(request_json["system"]);
        if (!system_text.empty()) {
            messages.push_back({{"role", "system"}, {"content", system_text}});
        }
    }
    if (request_json.contains("messages") && request_json["messages"].is_array()) {
        for (const auto& message : request_json["messages"]) {
            if (!message.is_object()) continue;
            auto role = message.value("role", std::string("user"));
            std::string content_text;
            if (message.contains("content")) content_text = ExtractAnthropicText(message["content"]);
            messages.push_back({{"role", role}, {"content", content_text}});
        }
    }
    return messages;
}

void SendSseEvent(httplib::DataSink& sink, const std::string& event, const json& data) {
    std::string chunk = "event: " + event + "\n";
    chunk += "data: " + data.dump() + "\n\n";
    sink.os.write(chunk.c_str(), chunk.size());
    sink.os.flush();
}

    const std::string getR1AssistantString(std::string assistant_content) {
    std::size_t pos = assistant_content.find("</think>");
    if (pos != std::string::npos) {
        assistant_content.erase(0, pos + std::string("</think>").length());
    }
    return trimLeadingWhitespace(assistant_content) + "<|end_of_sentence|>";
}

std::string GetR1UserString(std::string user_content, bool last) {
    return "<|User|>" + std::string(user_content) + "<|Assistant|>";
}

    std::vector<PromptItem> ConvertToR1(std::vector<PromptItem> chat_prompts) {
    if (chat_prompts.empty()) return chat_prompts;
    std::vector<PromptItem> result_prompts = {};
    result_prompts.emplace_back("system", "<|begin_of_sentence|>You are a helpful assistant.");
    auto iter = chat_prompts.begin();
    for (; iter != chat_prompts.end() - 1; ++iter) {
        if (iter->first == "system") continue;
        else if (iter->first == "assistant") result_prompts.emplace_back("assistant", getR1AssistantString(iter->second));
        else if (iter->first == "user") result_prompts.emplace_back("user", GetR1UserString(iter->second, false));
    }
    if (iter->first == "user") result_prompts.emplace_back("user", GetR1UserString(iter->second, true));
    else result_prompts.emplace_back("assistant", getR1AssistantString(iter->second));
    return result_prompts;
}

void MnncliServer::Answer(MNN::Transformer::Llm* llm, const json &messages, std::function<void(const std::string&)> on_result) {
  std::vector<PromptItem> prompts{};
  if (messages.is_array()) {
    for (const auto& item_json : messages) {
      PromptItem item;
      if (!FromJson(item_json, item)) { LOG_DEBUG("Error converting JSON object to PromptItem."); break; }
      prompts.push_back(item);
    }
  }
  std::stringstream response_buffer;
  Utf8StreamProcessor processor([&response_buffer, on_result](const std::string& utf8Char) {
    bool is_eop = utf8Char.find("<eop>") != std::string::npos;
    if (!is_eop) { response_buffer << utf8Char; }
    else { on_result(response_buffer.str()); }
    });
  LlmStreamBuffer stream_buffer{[&processor](const char* str, size_t len){ processor.processStream(str, len); }};
  std::ostream output_ostream(&stream_buffer);
  std::lock_guard<std::mutex> lock(llm_mutex_);
  llm->response(this->is_r1_ ? ConvertToR1(prompts) : prompts, &output_ostream, "<eop>");
}

void MnncliServer::AnswerStreaming(MNN::Transformer::Llm* llm,
                     const json& messages,
                     std::function<void(const std::string&, bool end)> on_partial) {
    std::vector<PromptItem> prompts;
    if (messages.is_array()) {
      for (const auto& item_json : messages) {
        PromptItem item;
        if (!FromJson(item_json, item)) { LOG_DEBUG("Error converting JSON object to PromptItem."); return; }
        prompts.push_back(item);
      }
    }
    std::string answer = "";
    Utf8StreamProcessor processor([&on_partial, &answer](const std::string &utf8Char) {
        bool is_eop = (utf8Char.find("<eop>") != std::string::npos);
        if (is_eop) { on_partial("", true); }
        else { answer += utf8Char; on_partial(utf8Char, false); }
    });
    LlmStreamBuffer stream_buffer([&processor](const char* str, size_t len) { processor.processStream(str, len); });
    std::ostream output_ostream(&stream_buffer);
    std::lock_guard<std::mutex> lock(llm_mutex_);
    llm->response(this->is_r1_ ? ConvertToR1(prompts) : prompts, &output_ostream, "<eop>");
}

void MnncliServer::AnswerMultimodal(MNN::Transformer::Llm* llm, const std::vector<int>& input_ids,
                                    std::function<void(const std::string&)> on_result) {
  std::stringstream response_buffer;
  Utf8StreamProcessor processor([&response_buffer, on_result](const std::string& utf8Char) {
    bool is_eop = utf8Char.find("<eop>") != std::string::npos;
    if (!is_eop) { response_buffer << utf8Char; }
    else { on_result(response_buffer.str()); }
    });
  LlmStreamBuffer stream_buffer{[&processor](const char* str, size_t len){ processor.processStream(str, len); }};
  std::ostream output_ostream(&stream_buffer);
  std::lock_guard<std::mutex> lock(llm_mutex_);
  llm->reset();
  llm->response(input_ids, &output_ostream, "<eop>");
}

void MnncliServer::AnswerMultimodalStreaming(MNN::Transformer::Llm* llm, const std::vector<int>& input_ids,
                                             std::function<void(const std::string&, bool end)> on_partial) {
    std::string answer = "";
    Utf8StreamProcessor processor([&on_partial, &answer](const std::string &utf8Char) {
        bool is_eop = (utf8Char.find("<eop>") != std::string::npos);
        if (is_eop) { on_partial("", true); }
        else { answer += utf8Char; on_partial(utf8Char, false); }
    });
    LlmStreamBuffer stream_buffer([&processor](const char* str, size_t len) { processor.processStream(str, len); });
    std::ostream output_ostream(&stream_buffer);
    std::lock_guard<std::mutex> lock(llm_mutex_);
    llm->reset();
    llm->response(input_ids, &output_ostream, "<eop>");
}

void AllowCors(httplib::Response& res) {
    res.set_header("Access-Control-Allow-Origin",  "*");
    res.set_header("Access-Control-Allow-Methods",  "GET, POST, PUT, DELETE, OPTIONS");
    res.set_header("Access-Control-Allow-Headers",  "Content-Type, Authorization");
}

// ---------------------------------------------------------------------------
// Free helpers (text extraction, KB context, image decoding)
// ---------------------------------------------------------------------------
namespace {

std::string extractTextContent(const json& content) {
    if (content.is_string()) return content.get<std::string>();
    if (content.is_array()) {
        std::string out;
        for (const auto& part : content) {
            std::string type = part.value("type", "");
            if (type == "text" && part.contains("text")) out += part["text"].get<std::string>();
        }
        return out;
    }
    return "";
}

bool contentHasImage(const json& content) {
    if (!content.is_array()) return false;
    for (const auto& part : content) {
        std::string type = part.value("type", "");
        if (type == "image_url" && part.contains("image_url")) return true;
    }
    return false;
}

std::string lastUserQuery(const json& messages) {
    std::string q;
    if (messages.is_array()) {
        for (auto it = messages.rbegin(); it != messages.rend(); ++it) {
            if ((*it).value("role", "") == "user") { q = extractTextContent((*it)["content"]); break; }
        }
    }
    return q;
}

bool anyImage(const json& messages) {
    if (messages.is_array()) {
        for (const auto& m : messages) {
            if (m.contains("content") && contentHasImage(m["content"])) return true;
        }
    }
    return false;
}

// Flatten every message to {role, content:string}, dropping images (text path).
json flattenMessages(const json& messages) {
    json out = json::array();
    if (messages.is_array()) {
        for (const auto& m : messages) {
            std::string role = m.value("role", "user");
            out.push_back({{"role", role}, {"content", extractTextContent(m["content"])}});
        }
    }
    return out;
}

std::string buildContextPrompt(const std::vector<mnncli::KbChunk>& chunks) {
    std::string ctx =
        "You are a helpful assistant. Use the following retrieved context to answer the "
        "user's question accurately and cite the document name when possible. "
        "If the context does not contain the answer, say you don't know based on the "
        "provided context.\n\n<context>\n";
    for (const auto& c : chunks) {
        ctx += "[Document: " + c.doc_name + " | score: " + std::to_string(c.score) + "]\n";
        ctx += c.text + "\n\n";
    }
    ctx += "</context>";
    return ctx;
}

std::string decodeBase64(const std::string& in) {
    static const std::string b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    int val = 0, bits = 0;
    for (char c : in) {
        if (c == ' ' || c == '\n' || c == '\r' || c == '\t') continue;
        if (c == '=') break;
        auto pos = b64.find(c);
        if (pos == std::string::npos) continue;
        val = (val << 6) | static_cast<int>(pos);
        bits += 6;
        if (bits >= 8) { bits -= 8; out.push_back(static_cast<char>((val >> bits) & 0xFF)); }
    }
    return out;
}

std::string writeTempFile(const std::string& bytes, const std::string& ext) {
    std::string dir = ".";
    try { dir = fs::temp_directory_path().string(); } catch (...) {}
    static std::atomic<int> cnt{0};
    std::string path = dir + "/mnn_kb_img_" + std::to_string(std::time(nullptr)) + "_" +
                       std::to_string(cnt++) + "." + ext;
    std::ofstream f(path, std::ios::binary);
    if (!f) return "";
    f.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    return path;
}

}  // namespace

void MnncliServer::saveUploadedText(KnowledgeBase& kb, const std::string& name, const std::string& text) {
    kb.addDocument(name, text);
}

std::string MnncliServer::decodeBase64(const std::string& in) { return decodeBase64(in); }

bool MnncliServer::loadImageToVar(const std::string& src, MNN::Express::VARP& out) {
    out = nullptr;
    if (src.empty()) return false;
    std::string path;
    bool temp = false;
    if (src.rfind("data:", 0) == 0) {
        auto comma = src.find(',');
        if (comma == std::string::npos) return false;
        std::string meta = src.substr(5, comma - 5);
        std::string bytes = decodeBase64(src.substr(comma + 1));
        std::string ext = "png";
        if (meta.find("jpeg") != std::string::npos) ext = "jpg";
        else if (meta.find("png") != std::string::npos) ext = "png";
        else if (meta.find("webp") != std::string::npos) ext = "webp";
        else if (meta.find("bmp") != std::string::npos) ext = "bmp";
        path = writeTempFile(bytes, ext);
        temp = true;
    } else if (src.rfind("http://", 0) == 0 || src.rfind("https://", 0) == 0) {
        std::string host = src.substr(0, src.find('/', 8));
        httplib::Client cli(host);
        cli.enable_server_certificate_verification(false);
        auto r = cli.Get(src.substr(host.size()));
        if (!r || r->status != 200) return false;
        std::string ext = "png";
        auto it = r->get_header_value("content-type");
        if (it.find("jpeg") != std::string::npos) ext = "jpg";
        else if (it.find("png") != std::string::npos) ext = "png";
        path = writeTempFile(r->body, ext);
        temp = true;
    } else {
        path = src;  // local file path
    }
    if (path.empty()) return false;
#ifdef MNN_IMGCODECS
    out = MNN::CV::imread(path);
#else
    LOG_WARNING("Image loading unavailable: rebuild libMNN with MNN_BUILD_LLM_OMNI=ON to enable image chat.");
    out = nullptr;
#endif
    if (temp) { std::error_code ec; fs::remove(path, ec); }
    return out.get() != nullptr;
}

std::vector<int> MnncliServer::prepareMultimodalInputIds(MNN::Transformer::Llm* llm,
                                                         const json& messages,
                                                         MNN::Transformer::MultimodalPrompt& mp) {
    MNN::Transformer::ChatMessages chat_prompts;
    int imgCounter = 0;
    if (messages.is_array()) {
        for (const auto& m : messages) {
            std::string role = m.value("role", "user");
            std::string text;
            const auto& content = m["content"];
            if (content.is_string()) {
                text = content.get<std::string>();
            } else if (content.is_array()) {
                for (const auto& part : content) {
                    std::string type = part.value("type", "");
                    if (type == "text" && part.contains("text")) {
                        text += part["text"].get<std::string>();
                    } else if (type == "image_url" && part.contains("image_url")) {
                        std::string url = part["image_url"].value("url", "");
                        MNN::Express::VARP var;
                        if (loadImageToVar(url, var) && var.get() != nullptr) {
                            std::string key = "img_" + std::to_string(imgCounter++);
                            text += "<img>" + key + "</img>\n";
                            MNN::Transformer::PromptImagePart pip;
                            pip.image_data = std::move(var);
                            pip.width = 0;
                            pip.height = 0;
                            mp.images[key] = std::move(pip);
                        } else {
                            LOG_WARNING("Failed to load image: " + url.substr(0, 48));
                        }
                    }
                }
            }
            chat_prompts.emplace_back(role, text);
        }
    }
    std::string formatted = llm->apply_chat_template(chat_prompts);
    mp.prompt_template = formatted;
    return llm->tokenizer_encode(mp);
}

// ---------------------------------------------------------------------------
// Server entry point
// ---------------------------------------------------------------------------
void MnncliServer::Start(MNN::Transformer::Llm* llm, MnncliServerOptions opt) {
    this->is_r1_ = opt.is_r1;
    this->vision_ = opt.vision;
    this->embedding_ = std::move(opt.embedding);
    this->kb_dir_ = opt.kb_dir;
    this->kb_top_k_ = opt.kb_top_k;
    this->reranker_model_ = std::move(opt.reranker_model);
    if (reranker_model_) reranker_ = std::make_unique<MnnReranker>(reranker_model_.get());
    if (embedding_) {
        embedder_ = std::make_unique<MnnEmbedder>(embedding_.get());
        kb_ = std::make_unique<KnowledgeBase>(embedder_.get());
        kb_->setChunkSize(opt.kb_chunk_size);
        kb_->setOverlap(opt.kb_chunk_size / 8);
        if (!kb_dir_.empty()) {
            std::error_code ec;
            fs::create_directories(kb_dir_, ec);
            std::string path = kb_dir_ + "/kb.bin";
            if (fs::exists(path, ec)) kb_->load(path);
        }
        kb_->setEnabled(opt.kb_enabled);
    }

    httplib::Server server;

    server.Get("/", [this](const httplib::Request& req, httplib::Response& res) {
        AllowCors(res);
        res.set_content(html_content, "text/html");
    });
    server.Post("/reset", [&](const httplib::Request &req, httplib::Response &res) {
      LOG_DEBUG("POST /reset");
      AllowCors(res);
      llm->reset();
      res.set_content("{\"status\": \"ok\"}", "application/json");
    });

    server.Get("/v1/models", [&](const httplib::Request &req, httplib::Response &res) {
      LOG_DEBUG("GET /v1/models");
      AllowCors(res);
      json models_response = {
        {"object", "list"},
        {"data", json::array({
          {{"id", "ModelScope/MNN/Qwen2.5-0.5B-Instruct"},
           {"object", "model"},
           {"created", static_cast<int>(time(nullptr))},
           {"owned_by", "mnn"}}
        })}
      };
      res.set_content(models_response.dump(), "application/json");
    });
    server.Options("/v1/models", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    // ---------------- Knowledge base endpoints ----------------
    auto kbStatusHandler = [&](const httplib::Request&, httplib::Response& res) {
        AllowCors(res);
        json out = {
            {"available", kb_ != nullptr},
            {"enabled", kb_ ? kb_->enabled() : false},
            {"documents", kb_ ? static_cast<int>(kb_->docCount()) : 0},
            {"chunks", kb_ ? static_cast<int>(kb_->chunkCount()) : 0},
            {"top_k", static_cast<int>(kb_top_k_)},
            {"vision", vision_}
        };
        if (kb_) out["doc_names"] = kb_->docNames();
        res.set_content(out.dump(), "application/json");
    };
    server.Get("/v1/kb/status", kbStatusHandler);
    server.Options("/v1/kb/status", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    server.Get("/v1/kb/documents", [&](const httplib::Request&, httplib::Response& res) {
        AllowCors(res);
        if (!kb_) { res.status = 400; res.set_content(R"({"error":"knowledge base not enabled"})", "application/json"); return; }
        json out = {{"documents", kb_->docNames()}};
        res.set_content(out.dump(), "application/json");
    });
    server.Options("/v1/kb/documents", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    server.Delete("/v1/kb/documents", [&](const httplib::Request&, httplib::Response& res) {
        AllowCors(res);
        if (!kb_) { res.status = 400; res.set_content(R"({"error":"knowledge base not enabled"})", "application/json"); return; }
        kb_->clear();
        if (!kb_dir_.empty()) kb_->save(kb_dir_ + "/kb.bin");
        res.set_content(R"({"ok":true})", "application/json");
    });
    server.Options("/v1/kb/documents", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    server.Post("/v1/kb/toggle", [&](const httplib::Request &req, httplib::Response &res) {
        AllowCors(res);
        if (!kb_) { res.status = 400; res.set_content(R"KBERR({"error":"knowledge base not enabled (start with --kb-embedding)"})KBERR", "application/json"); return; }
        bool on = false;
        if (json::accept(req.body)) {
            auto j = json::parse(req.body, nullptr, false);
            if (j.is_object()) on = j.value("enabled", false);
        }
        kb_->setEnabled(on);
        if (!kb_dir_.empty()) kb_->save(kb_dir_ + "/kb.bin");
        json out = {{"ok", true}, {"enabled", on}};
        res.set_content(out.dump(), "application/json");
    });
    server.Options("/v1/kb/toggle", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    server.Post("/v1/kb/upload", [&](const httplib::Request &req, httplib::Response &res) {
        AllowCors(res);
        if (!kb_) { res.status = 400; res.set_content(R"({"ok":false,"error":"knowledge base not enabled"})", "application/json"); return; }
        std::string name, text;
        if (req.form.has_file("file")) {
            auto f = req.form.get_file("file");
            name = f.filename;
            text = f.content;
        } else if (json::accept(req.body)) {
            auto j = json::parse(req.body, nullptr, false);
            if (j.is_object()) {
                name = j.value("filename", "");
                text = j.value("content", "");
            }
        }
        if (text.empty()) {
            res.status = 400;
            res.set_content(R"({"ok":false,"error":"empty content"})", "application/json");
            return;
        }
        if (name.empty()) name = "doc-" + std::to_string(std::time(nullptr));
        kb_->addDocument(name, text);
        if (!kb_dir_.empty()) kb_->save(kb_dir_ + "/kb.bin");
        json out = {{"ok", true},
                    {"name", name},
                    {"chunks", static_cast<int>(kb_->chunkCount())},
                    {"total_chunks", static_cast<int>(kb_->chunkCount())}};
        res.set_content(out.dump(), "application/json");
    });
    server.Options("/v1/kb/upload", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    server.Post("/v1/kb/search", [&](const httplib::Request &req, httplib::Response &res) {
        AllowCors(res);
        if (!kb_) { res.status = 400; res.set_content(R"({"error":"knowledge base not enabled"})", "application/json"); return; }
        std::string query;
        int top_k = static_cast<int>(kb_top_k_);
        if (json::accept(req.body)) {
            auto j = json::parse(req.body, nullptr, false);
            if (j.is_object()) { query = j.value("query", ""); top_k = j.value("top_k", static_cast<int>(kb_top_k_)); }
        }
        auto chunks = kb_->retrieve(query, top_k);
        json arr = json::array();
        for (const auto& c : chunks) {
            arr.push_back({{"doc_name", c.doc_name}, {"score", c.score}, {"text", c.text}});
        }
        json out = {{"query", query}, {"results", arr}};
        res.set_content(out.dump(), "application/json");
    });
    server.Options("/v1/kb/search", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    // ---------------- Chat completions (text + KB + image) ----------------
    server.Options("/chat/completions", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });
    server.Options("/v1/chat/completions", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    auto chatCompletionsHandler = [&](const httplib::Request &req, httplib::Response &res) {
        LOG_DEBUG("POST chat/completions, thread: " + std::to_string(std::hash<std::thread::id>{}(std::this_thread::get_id())));
        AllowCors(res);
        if (!json::accept(req.body)) {
            json err; err["error"] = "Invalid JSON in request body.";
            res.status = 400; res.set_content(err.dump(), "application/json"); return;
        }
        json request_json = json::parse(req.body, nullptr, false);
        if (!request_json.is_object()) {
            json err; err["error"] = "Request body must be a JSON object.";
            res.status = 400; res.set_content(err.dump(), "application/json"); return;
        }
        json messages = request_json["messages"];
        std::string model = request_json.value("model", "undefined-model");
        bool stream = request_json.value("stream", false);

        // ---- Knowledge-base retrieval (the RAG "switch") ----
        bool kbOn = kb_ && (kb_->enabled() || request_json.value("knowledge_base", false));
        std::string query = lastUserQuery(messages);
        bool useRerank = request_json.value("kb_rerank", false) && reranker_ != nullptr;
        size_t top_k = static_cast<size_t>(request_json.value("kb_top_k", static_cast<int>(kb_top_k_)));
        if (kbOn && !query.empty()) {
            std::vector<KbChunk> chunks;
            if (useRerank) {
                chunks = kb_->retrieve(query, top_k, reranker_.get(), std::max(top_k * 4, static_cast<size_t>(8)));
            } else {
                chunks = kb_->retrieve(query, top_k);
            }
            if (!chunks.empty()) {
                std::string ctx = buildContextPrompt(chunks);
                json sysMsg = {{"role", "system"}, {"content", ctx}};
                messages.insert(messages.begin(), sysMsg);
            }
        }

        // ---- Decide text vs multimodal path ----
        bool hasImages = anyImage(messages);
        MNN::Transformer::MultimodalPrompt mp;
        std::vector<int> multiIds;
        bool useMultimodal = false;
        if (hasImages && vision_) {
            multiIds = prepareMultimodalInputIds(llm, messages, mp);
            useMultimodal = !multiIds.empty();
            if (!useMultimodal) LOG_WARNING("Image present but multimodal input preparation failed; falling back to text.");
        }
        json textMessages = flattenMessages(messages);

        if (!stream) {
            if (useMultimodal) {
                AnswerMultimodal(llm, multiIds, [&res, model](const std::string& answer) {
                    json response_json = {
                        {"id", "chatcmpl" + GetCurrentTimeAsString()},
                        {"object", "chat.completion"},
                        {"created", static_cast<int>(time(nullptr))},
                        {"model", model},
                        {"choices", json::array({{
                            {"index", 0},
                            {"message", {{"role", "assistant"}, {"content", answer}}},
                            {"finish_reason", "stop"}
                        }})},
                        {"usage", {{"prompt_tokens", 10}, {"completion_tokens", 7}, {"total_tokens", 17}}}
                    };
                    res.set_content(response_json.dump(), "application/json");
                });
            } else {
                Answer(llm, textMessages, [&res, model](const std::string& answer) {
                    json response_json = {
                        {"id", "chatcmpl" + GetCurrentTimeAsString()},
                        {"object", "chat.completion"},
                        {"created", static_cast<int>(time(nullptr))},
                        {"model", model},
                        {"choices", json::array({{
                            {"index", 0},
                            {"message", {{"role", "assistant"}, {"content", answer}}},
                            {"finish_reason", "stop"}
                        }})},
                        {"usage", {{"prompt_tokens", 10}, {"completion_tokens", 7}, {"total_tokens", 17}}}
                    };
                    res.set_content(response_json.dump(), "application/json");
                });
            }
            return;
        }

        res.set_header("Content-Type", "text/event-stream");
        res.set_header("Cache-Control", "no-cache");
        res.set_header("Connection", "keep-alive");
        res.set_chunked_content_provider(
            "text/event-stream",
            [llm, model, this, useMultimodal, multiIds, textMessages](size_t /*offset*/, httplib::DataSink &sink) {
                auto sse_callback = [&, this](const std::string &partial_text, bool end) {
                    std::string finish_reason = end ? "stop" : "";
                    json sse_json = {
                        {"id", "chatcmpl-" + GetCurrentTimeAsString()},
                        {"object", "chat.completion.chunk"},
                        {"created", static_cast<int>(std::time(nullptr))},
                        {"model", model},
                        {"choices", json::array({{
                            {"delta", {{"content", partial_text}}},
                            {"index", 0},
                            {"finish_reason", finish_reason}
                        }})}
                    };
                    std::string chunk_str = "data: " + sse_json.dump() + "\n\n";
                    sink.os.write(chunk_str.c_str(), chunk_str.size());
                    sink.os.flush();
                };
                if (useMultimodal) AnswerMultimodalStreaming(llm, multiIds, sse_callback);
                else AnswerStreaming(llm, textMessages, sse_callback);
                std::string done_str = "data: [DONE]\n\n";
                sink.os.write(done_str.c_str(), done_str.size());
                sink.os.flush();
                sink.done();
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                return false;
            }
        );
    };

    server.Post("/chat/completions", chatCompletionsHandler);
    server.Post("/v1/chat/completions", chatCompletionsHandler);

    auto anthropicMessagesHandler = [&](const httplib::Request &req, httplib::Response &res) {
      LOG_DEBUG("POST /v1/messages");
      AllowCors(res);
      if (!json::accept(req.body)) {
          json err; err["error"] = "Invalid JSON in request body.";
          res.status = 400; res.set_content(err.dump(), "application/json"); return;
      }
      json request_json = json::parse(req.body, nullptr, false);
      if (!request_json.is_object()) {
          json err; err["error"] = "Request body must be a JSON object.";
          res.status = 400; res.set_content(err.dump(), "application/json"); return;
      }
      json messages = BuildOpenAiMessagesFromAnthropicRequest(request_json);
      std::string model = request_json.value("model", "undefined-model");
      bool stream = request_json.value("stream", false);
      if (!stream) {
          Answer(llm, messages, [&res, model](const std::string& answer) {
              json response_json = {
                  {"id", "msg_" + GetCurrentTimeAsString()},
                  {"type", "message"},
                  {"role", "assistant"},
                  {"content", json::array({{{"type", "text"}, {"text", answer}}})},
                  {"model", model},
                  {"stop_reason", "end_turn"},
                  {"stop_sequence", nullptr},
                  {"usage", {{"input_tokens", 0}, {"output_tokens", 0}}}
              };
              res.set_content(response_json.dump(), "application/json");
          });
          return;
      }
      const std::string response_id = "msg_" + GetCurrentTimeAsString();
      res.set_header("Content-Type", "text/event-stream");
      res.set_header("Cache-Control", "no-cache");
      res.set_header("Connection", "keep-alive");
      res.set_chunked_content_provider(
          "text/event-stream",
          [llm, messages, model, response_id, this](size_t /*offset*/, httplib::DataSink &sink) {
              SendSseEvent(sink, "message_start", {
                  {"type", "message_start"},
                  {"message", {{"id", response_id}, {"type", "message"}, {"role", "assistant"},
                               {"model", model}, {"content", json::array()},
                               {"usage", {{"input_tokens", 0}, {"output_tokens", 0}}}}}
              });
              SendSseEvent(sink, "content_block_start", {
                  {"type", "content_block_start"}, {"index", 0},
                  {"content_block", {{"type", "text"}, {"text", ""}}}
              });
              int output_tokens = 0;
              auto anthropic_sse_callback = [&](const std::string &partial_text, bool end) {
                  if (end) return;
                  if (!partial_text.empty()) output_tokens += 1;
                  SendSseEvent(sink, "content_block_delta", {
                      {"type", "content_block_delta"}, {"index", 0},
                      {"delta", {{"type", "text_delta"}, {"text", partial_text}}}
                  });
              };
              AnswerStreaming(llm, messages, anthropic_sse_callback);
              SendSseEvent(sink, "content_block_stop", {{"type", "content_block_stop"}, {"index", 0}});
              SendSseEvent(sink, "message_delta", {
                  {"type", "message_delta"},
                  {"delta", {{"stop_reason", "end_turn"}, {"stop_sequence", nullptr}}},
                  {"usage", {{"input_tokens", 0}, {"output_tokens", output_tokens}}}
              });
              SendSseEvent(sink, "message_stop", {{"type", "message_stop"}});
              sink.done();
              std::this_thread::sleep_for(std::chrono::milliseconds(10));
              return false;
          }
      );
    };
    server.Post("/v1/messages", anthropicMessagesHandler);
    server.Options("/v1/messages", [](const httplib::Request&, httplib::Response& res) { AllowCors(res); res.status = 200; });

    LOG_DEBUG("✅ Model initialized successfully!");
    LOG_DEBUG("🚀 Server ready at http://" + opt.host + ":" + std::to_string(opt.port));
    if (kb_) LOG_DEBUG(std::string("📚 Knowledge base: ") + (kb_->enabled() ? "ON" : "off") +
                       " (" + std::to_string(kb_->chunkCount()) + " chunks)");
    if (vision_) LOG_DEBUG("🖼️ Vision/multimodal mode enabled");
    if (!server.listen(opt.host.c_str(), opt.port)) {
        LOG_DEBUG("Error: Could not start server on " + opt.host + ":" + std::to_string(opt.port));
    }
}

}  // namespace mnncli
