//
//  embedder_mnn.cpp
//
//  Copyright (c) 2026 Alibaba Group Holding Limited. All rights reserved.
//

#include "embedder_mnn.hpp"

#include <MNN/expr/Expr.hpp>
#include <llm/llm.hpp>
#include <llm/reranker.hpp>

#include <cmath>

namespace mnncli {

MnnEmbedder::MnnEmbedder(MNN::Transformer::Embedding* embedding)
    : embedding_(embedding) {}

std::vector<float> MnnEmbedder::embed(const std::string& text) {
    std::vector<float> out;
    if (!embedding_) return out;
    auto var = embedding_->txt_embedding(text);
    if (var == nullptr) return out;
    auto ptr = var->readMap<float>();
    const size_t n = static_cast<size_t>(var->getInfo()->size);
    out.assign(ptr, ptr + n);
    if (dim_ == 0) dim_ = n;
    // L2-normalize so cosine == dot product.
    double norm = 0.0;
    for (float v : out) norm += static_cast<double>(v) * v;
    norm = std::sqrt(norm);
    if (norm > 0.0) {
        const float inv = static_cast<float>(1.0 / norm);
        for (float& v : out) v *= inv;
    }
    return out;
}

size_t MnnEmbedder::dim() const {
    if (dim_ != 0) return dim_;
    if (!embedding_) return 0;
    return static_cast<size_t>(embedding_->dim());
}

MnnReranker::MnnReranker(MNN::Transformer::RerankerBase* reranker)
    : reranker_(reranker) {}

std::vector<float> MnnReranker::score(const std::string& query,
                                      const std::vector<std::string>& documents) {
    if (!reranker_) return {};
    return reranker_->compute_scores(query, documents);
}

}  // namespace mnncli
