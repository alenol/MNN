//
//  knowledge_base.cpp
//
//  Copyright (c) 2026 Alibaba Group Holding Limited. All rights reserved.
//

#include "knowledge_base.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <cstring>
#include <unordered_set>

namespace mnncli {

namespace {
// Returns true if `text[pos..pos+2]` is a 3-byte UTF-8 CJK/full-width
// punctuation mark (。！？；：， etc.), so Chinese text is split on natural
// sentence boundaries rather than only on ASCII punctuation.
bool isCjkBreak(const std::string& text, size_t pos) {
    if (pos + 2 >= text.size()) return false;
    const unsigned char* p = reinterpret_cast<const unsigned char*>(text.data() + pos);
    // Full-width punctuation lives in the EF BC 8x / EF BC 9x range, and the
    // ideographic full stop / comma in E3 80 8x.
    if (p[0] == 0xEF && p[1] == 0xBC &&
        ((p[2] >= 0x81 && p[2] <= 0x9F)))  // ！＂＃…（）＊＋，－．／：；＜＝＞？＠［＼］＾＿｀｛｜｝～ and 。
        return true;
    if (p[0] == 0xE3 && p[1] == 0x80 && (p[2] == 0x81 || p[2] == 0x82))  // 、 。
        return true;
    return false;
}

// Pick a sentence/paragraph boundary near `hint` (scanning backwards) so chunks
// do not cut words mid-sentence when possible.
size_t findBreak(const std::string& text, size_t start, size_t hint) {
    size_t lo = start + std::max<size_t>(1, hint / 2);
    if (hint <= lo) return hint;
    size_t br = hint;
    while (br > lo) {
        char c = text[br];
        if (c == '\n' || c == '.' || c == '!' || c == '?' ||
            c == ';' || c == ':') {
            return br + 1;  // keep the punctuation inside the current chunk
        }
        if (isCjkBreak(text, br)) {
            return br + 3;  // keep the whole 3-byte punctuation inside the chunk
        }
        --br;
    }
    return hint;
}

void writeU32(std::ostream& os, uint32_t v) {
    os.write(reinterpret_cast<const char*>(&v), sizeof(v));
}
void writeStr(std::ostream& os, const std::string& s) {
    writeU32(os, static_cast<uint32_t>(s.size()));
    if (!s.empty()) os.write(s.data(), static_cast<std::streamsize>(s.size()));
}
bool readU32(std::istream& is, uint32_t& v) {
    return static_cast<bool>(is.read(reinterpret_cast<char*>(&v), sizeof(v)));
}
bool readStr(std::istream& is, std::string& s) {
    uint32_t n = 0;
    if (!readU32(is, n)) return false;
    s.resize(n);
    if (n > 0) is.read(&s[0], static_cast<std::streamsize>(n));
    return static_cast<bool>(is);
}
}  // namespace

KnowledgeBase::KnowledgeBase(Embedder* embedder)
    : embedder_(embedder) {}

std::vector<std::string> KnowledgeBase::splitIntoChunks(const std::string& text,
                                                        size_t chunk_size,
                                                        size_t overlap) {
    std::vector<std::string> chunks;
    if (text.empty()) return chunks;
    if (chunk_size == 0) chunk_size = 1;
    if (overlap >= chunk_size) overlap = chunk_size / 2;

    size_t start = 0;
    const size_t n = text.size();
    while (start < n) {
        size_t end = std::min(start + chunk_size, n);
        if (end < n) {
            end = findBreak(text, start, end);
        }
        chunks.push_back(text.substr(start, end - start));
        if (end >= n) break;
        size_t next = (end > overlap) ? end - overlap : end;
        if (next <= start) next = end;  // guarantee progress
        start = next;
    }
    return chunks;
}

float KnowledgeBase::cosine(const std::vector<float>& a, const std::vector<float>& b) {
    if (a.empty() || b.empty() || a.size() != b.size()) return 0.0f;
    double dot = 0.0, na = 0.0, nb = 0.0;
    for (size_t i = 0; i < a.size(); ++i) {
        dot += static_cast<double>(a[i]) * static_cast<double>(b[i]);
        na += static_cast<double>(a[i]) * static_cast<double>(a[i]);
        nb += static_cast<double>(b[i]) * static_cast<double>(b[i]);
    }
    if (na == 0.0 || nb == 0.0) return 0.0f;
    return static_cast<float>(dot / (std::sqrt(na) * std::sqrt(nb)));
}

void KnowledgeBase::addDocument(const std::string& name, const std::string& text) {
    if (text.empty()) return;
    std::vector<std::string> parts = splitIntoChunks(text, chunk_size_, overlap_);
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& part : parts) {
        if (part.empty()) continue;
        KbChunk chunk;
        chunk.doc_name = name;
        chunk.text = part;
        if (embedder_) {
            chunk.vector = embedder_->embed(part);
        }
        chunks_.push_back(std::move(chunk));
    }
    if (!name.empty()) {
        bool found = false;
        for (const auto& d : doc_names_) {
            if (d == name) { found = true; break; }
        }
        if (!found) doc_names_.push_back(name);
    }
}

void KnowledgeBase::addText(const std::string& text) {
    static uint64_t counter = 0;
    std::string name = "paste-" + std::to_string(++counter);
    addDocument(name, text);
}

std::vector<KbChunk> KnowledgeBase::retrieve(const std::string& query,
                                             size_t top_k) const {
    if (!enabled_ || query.empty() || !embedder_ || top_k == 0) return {};
    std::vector<float> qvec = embedder_->embed(query);
    if (qvec.empty()) return {};

    std::lock_guard<std::mutex> lock(mutex_);
    // (score, index) pairs
    std::vector<std::pair<float, size_t>> scored;
    scored.reserve(chunks_.size());
    for (size_t i = 0; i < chunks_.size(); ++i) {
        if (chunks_[i].vector.empty()) continue;
        float s = cosine(qvec, chunks_[i].vector);
        scored.emplace_back(s, i);
    }
    std::sort(scored.begin(), scored.end(),
              [](const auto& a, const auto& b) { return a.first > b.first; });
    if (scored.size() > top_k) scored.resize(top_k);

    std::vector<KbChunk> out;
    out.reserve(scored.size());
    for (auto& p : scored) {
        KbChunk c = chunks_[p.second];
        c.score = p.first;
        out.push_back(std::move(c));
    }
    return out;
}

std::vector<KbChunk> KnowledgeBase::retrieve(const std::string& query, size_t top_k,
                                             KbReranker* reranker,
                                             size_t candidate_k) const {
    if (!enabled_ || query.empty() || !embedder_ || top_k == 0) return {};
    if (candidate_k < top_k) candidate_k = top_k;
    std::vector<KbChunk> candidates = retrieve(query, candidate_k);
    if (candidates.empty() || !reranker) return candidates;

    std::vector<std::string> docs;
    docs.reserve(candidates.size());
    for (auto& c : candidates) docs.push_back(c.text);

    std::vector<float> scores = reranker->score(query, docs);
    if (scores.size() != candidates.size()) return candidates;

    std::vector<std::pair<float, size_t>> ranked;
    ranked.reserve(candidates.size());
    for (size_t i = 0; i < candidates.size(); ++i) ranked.emplace_back(scores[i], i);
    std::sort(ranked.begin(), ranked.end(),
              [](const auto& a, const auto& b) { return a.first > b.first; });
    if (ranked.size() > top_k) ranked.resize(top_k);

    std::vector<KbChunk> out;
    out.reserve(ranked.size());
    for (auto& p : ranked) {
        KbChunk c = candidates[p.second];
        c.score = p.first;
        out.push_back(std::move(c));
    }
    return out;
}

size_t KnowledgeBase::chunkCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return chunks_.size();
}
size_t KnowledgeBase::docCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return doc_names_.size();
}
std::vector<std::string> KnowledgeBase::docNames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return doc_names_;
}
void KnowledgeBase::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    chunks_.clear();
    doc_names_.clear();
}

bool KnowledgeBase::save(const std::string& path) const {
    std::ofstream os(path, std::ios::binary);
    if (!os) return false;
    const char magic[4] = {'M', 'N', 'N', 'K'};
    os.write(magic, 4);
    writeU32(os, 1);  // version
    writeU32(os, static_cast<uint32_t>(chunk_size_));
    writeU32(os, static_cast<uint32_t>(overlap_));
    std::lock_guard<std::mutex> lock(mutex_);
    writeU32(os, static_cast<uint32_t>(chunks_.size()));
    for (const auto& c : chunks_) {
        writeStr(os, c.doc_name);
        writeStr(os, c.text);
        writeU32(os, static_cast<uint32_t>(c.vector.size()));
        if (!c.vector.empty()) {
            os.write(reinterpret_cast<const char*>(c.vector.data()),
                     static_cast<std::streamsize>(c.vector.size() * sizeof(float)));
        }
    }
    return static_cast<bool>(os);
}

bool KnowledgeBase::load(const std::string& path) {
    std::ifstream is(path, std::ios::binary);
    if (!is) return false;
    char magic[4] = {0, 0, 0, 0};
    is.read(magic, 4);
    if (std::memcmp(magic, "MNNK", 4) != 0) return false;
    uint32_t version = 0, cs = 0, ov = 0, count = 0;
    if (!readU32(is, version)) return false;
    if (!readU32(is, cs)) return false;
    if (!readU32(is, ov)) return false;
    if (!readU32(is, count)) return false;
    if (version != 1) return false;

    std::vector<KbChunk> loaded;
    loaded.reserve(count);
    std::unordered_set<std::string> names;
    for (uint32_t i = 0; i < count; ++i) {
        KbChunk c;
        if (!readStr(is, c.doc_name)) return false;
        if (!readStr(is, c.text)) return false;
        uint32_t dim = 0;
        if (!readU32(is, dim)) return false;
        c.vector.resize(dim);
        if (dim > 0) {
            is.read(reinterpret_cast<char*>(c.vector.data()),
                    static_cast<std::streamsize>(dim * sizeof(float)));
        }
        if (!is) return false;
        if (!c.doc_name.empty()) names.insert(c.doc_name);
        loaded.push_back(std::move(c));
    }
    if (!is) return false;

    std::lock_guard<std::mutex> lock(mutex_);
    chunks_ = std::move(loaded);
    doc_names_.assign(names.begin(), names.end());
    chunk_size_ = cs;
    overlap_ = ov;
    return true;
}

}  // namespace mnncli
