//
//  knowledge_base.hpp
//
//  Local knowledge base for MNN LLM Server (RAG).
//
//  Pure C++ module (no MNN dependency) so it can be unit-tested standalone.
//  It turns documents into chunks, embeds each chunk through an Embedder,
//  and retrieves the most relevant chunks for a query via cosine similarity
//  (optionally refined by a reranker). A boolean toggle enables/disables the
//  knowledge base at runtime.
//
//  Copyright (c) 2026 Alibaba Group Holding Limited. All rights reserved.
//

#pragma once

#include <string>
#include <vector>
#include <memory>
#include <mutex>

namespace mnncli {

// Embedding backend. Implementations produce L2-normalized vectors so that
// cosine similarity reduces to a dot product.
class Embedder {
public:
    virtual ~Embedder() = default;
    // Embed a single text snippet into a fixed-dimensional vector.
    virtual std::vector<float> embed(const std::string& text) = 0;
    // Dimensionality of the produced vectors.
    virtual size_t dim() const = 0;
};

// Reranker backend used to refine an initial candidate set.
class KbReranker {
public:
    virtual ~KbReranker() = default;
    // Returns one score per document (higher = more relevant to the query).
    virtual std::vector<float> score(const std::string& query,
                                     const std::vector<std::string>& documents) = 0;
};

// A single indexed chunk of a document.
struct KbChunk {
    std::string text;            // original chunk text
    std::string doc_name;        // source document name
    std::vector<float> vector;   // L2-normalized embedding
    float score = 0.0f;          // similarity/rerank score, set by retrieve()
};

// In-memory local knowledge base with optional on-disk persistence.
class KnowledgeBase {
public:
    // embedder must outlive the KnowledgeBase (it is not owned).
    explicit KnowledgeBase(Embedder* embedder);

    // ---- Runtime toggle (the "switch" requested by the user) ----
    void setEnabled(bool on) { enabled_ = on; }
    bool enabled() const { return enabled_; }

    // ---- Chunking parameters ----
    void setChunkSize(size_t n) { chunk_size_ = n; }
    void setOverlap(size_t n) { overlap_ = n; }
    size_t chunkSize() const { return chunk_size_; }
    size_t overlap() const { return overlap_; }

    // ---- Ingestion ----
    // Ingest a named document: chunk it, embed every chunk and store it.
    void addDocument(const std::string& name, const std::string& text);
    // Ingest raw pasted text under an auto-generated name.
    void addText(const std::string& text);

    // ---- Retrieval ----
    // Top-k chunks by cosine similarity. Returns an empty vector when disabled
    // or empty.
    std::vector<KbChunk> retrieve(const std::string& query, size_t top_k) const;
    // Two-stage retrieval: fetch candidate_k by cosine, then rerank to top_k.
    std::vector<KbChunk> retrieve(const std::string& query, size_t top_k,
                                  KbReranker* reranker, size_t candidate_k) const;

    // ---- Introspection / management ----
    size_t chunkCount() const;
    size_t docCount() const;
    std::vector<std::string> docNames() const;
    void clear();

    // ---- Persistence (portable binary format) ----
    bool save(const std::string& path) const;
    bool load(const std::string& path);

    // ---- Pure helpers (kept static for easy unit testing) ----
    // Split text into overlapping chunks, sentence/paragraph aware with a
    // character-based fallback.
    static std::vector<std::string> splitIntoChunks(const std::string& text,
                                                    size_t chunk_size, size_t overlap);
    // Cosine similarity between two vectors (safe for zero vectors).
    static float cosine(const std::vector<float>& a, const std::vector<float>& b);

private:
    Embedder* embedder_;
    bool enabled_ = false;
    size_t chunk_size_ = 512;
    size_t overlap_ = 64;
    mutable std::mutex mutex_;
    std::vector<KbChunk> chunks_;
    std::vector<std::string> doc_names_;
};

}  // namespace mnncli
