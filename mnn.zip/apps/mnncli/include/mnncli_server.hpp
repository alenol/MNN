//
// Created by ruoyi.sjd on 2024/12/25.
// Copyright (c) 2024 Alibaba Group Holding Limited All rights reserved.
//
// Modified 2026: local knowledge base (RAG) + toggle, document upload,
// and image (multimodal) upload support for the MNN LLM chat server.
//

#pragma once
#include "../../../transformers/llm/engine/include/llm/llm.hpp"
#include "httplib.h"
#include "json.hpp"
#include "knowledge_base.hpp"
#include "embedder_mnn.hpp"
#include <MNN/ImageProcess.hpp>
#include <memory>
#include <mutex>
#include <vector>
#include <string>
#include <functional>

using nlohmann::json;
using PromptItem = std::pair<std::string, std::string>;

namespace mnncli {

// Configuration passed from the `serve` command handler into the server.
struct MnncliServerOptions {
    bool is_r1 = false;                              // DeepSeek-R1 style prompt formatting
    std::string host = "127.0.0.1";
    int port = 8000;
    bool vision = false;                             // model is multimodal / vision-capable
    std::shared_ptr<MNN::Transformer::Embedding> embedding;  // nullable; enables KB
    std::unique_ptr<MNN::Transformer::RerankerBase> reranker_model;  // nullable; 2nd-stage rerank
    std::string kb_dir;                              // persistence directory for the KB
    bool kb_enabled = false;                         // initial toggle state
    size_t kb_chunk_size = 512;                      // chunk size in chars
    size_t kb_top_k = 4;                             // default retrieval count
};

class LlmStreamBuffer : public std::streambuf {
public:
  using CallBack = std::function<void(const char* str, size_t len)>;
  explicit LlmStreamBuffer(CallBack callback) : callback_(std::move(callback)) {}
  ~LlmStreamBuffer() override = default;
protected:
  virtual std::streamsize xsputn(const char* s, std::streamsize n) override {
    if (callback_) {
      callback_(s, n);
    }
    return n;
  }

private:
  CallBack callback_{};
};

class Utf8StreamProcessor {
  public:
    Utf8StreamProcessor(std::function<void(const std::string&)> callback)
            : callback(callback) {}

    void processStream(const char* str, size_t len) {
      utf8Buffer.append(str, len);

      size_t i = 0;
      std::string completeChars;
      while (i < utf8Buffer.size()) {
        int length = utf8CharLength(static_cast<unsigned char>(utf8Buffer[i]));
        if (length == 0 || i + length > utf8Buffer.size()) {
          break;
        }
        completeChars.append(utf8Buffer, i, length);
        i += length;
      }
      utf8Buffer = utf8Buffer.substr(i);
      if (!completeChars.empty()) {
        callback(completeChars);
      }
    }
    int utf8CharLength(unsigned char byte) {
      if ((byte & 0x80) == 0) return 1;
      if ((byte & 0xE0) == 0xC0) return 2;
      if ((byte & 0xF0) == 0xE0) return 3;
      if ((byte & 0xF8) == 0xF0) return 4;
      return 0;
    }
  private:
    std::string utf8Buffer;
    std::function<void(const std::string&)> callback;
  };

class MnncliServer {
  public:
    // Enhanced web UI: knowledge-base toggle, document upload, image attach.
    const char* html_content = R"""(<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>MNN Chat</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 1rem; background:#f5f5f5; min-height:100vh; }
    .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.2rem 1rem; text-align: center; }
    .header h1 { margin: 0 0 .3rem; font-size: 1.4rem; }
    .header p { margin: 0; font-size: .85rem; opacity: .9; }
    .toolbar { display:flex; flex-wrap:wrap; align-items:center; gap:.6rem; padding:.8rem 1rem; background:#f8f9fa; border-bottom:1px solid #e9ecef; }
    .toolbar .group { display:flex; align-items:center; gap:.4rem; }
    .switch { position:relative; display:inline-block; width:46px; height:24px; }
    .switch input { opacity:0; width:0; height:0; }
    .slider { position:absolute; cursor:pointer; inset:0; background:#ccc; transition:.2s; border-radius:24px; }
    .slider:before { content:""; position:absolute; height:18px; width:18px; left:3px; bottom:3px; background:#fff; transition:.2s; border-radius:50%; }
    .switch input:checked + .slider { background:#007bff; }
    .switch input:checked + .slider:before { transform:translateX(22px); }
    .btn { padding:.45rem .8rem; font-size:.85rem; border:none; border-radius:6px; cursor:pointer; font-weight:500; }
    .btn-primary { background:#007bff; color:#fff; }
    .btn-secondary { background:#6c757d; color:#fff; }
    .btn-ghost { background:#e9ecef; color:#333; }
    .kb-status { font-size:.8rem; color:#495057; }
    #chat-container { height:420px; overflow-y:auto; padding:1rem; background:#fff; }
    .message { margin-bottom:1rem; padding:.7rem; border-radius:8px; max-width:88%; word-wrap:break-word; white-space:pre-wrap; }
    .user { background:#e3f2fd; margin-left:auto; text-align:right; }
    .assistant { background:#f1f3f4; margin-right:auto; }
    .message strong { display:block; margin-bottom:.25rem; font-size:.78rem; opacity:.7; }
    .thumbs { display:flex; flex-wrap:wrap; gap:.4rem; margin:.3rem 0; }
    .thumb { position:relative; }
    .thumb img { height:54px; border-radius:6px; border:1px solid #ccc; }
    .thumb .x { position:absolute; top:-6px; right:-6px; background:#dc3545; color:#fff; border:none; border-radius:50%; width:18px; height:18px; cursor:pointer; font-size:.7rem; line-height:1; }
    .input-area { padding:1rem; background:#f8f9fa; border-top:1px solid #e9ecef; }
    #user-input { width:100%; padding:.7rem; border:1px solid #ced4da; border-radius:6px; font-size:1rem; }
    .row { display:flex; gap:.5rem; margin-top:.5rem; align-items:center; }
    .status { margin-top:.5rem; font-size:.82rem; color:#495057; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Chat with MNN</h1>
      <p>OpenAI-compatible API. Local knowledge base (RAG) &amp; image chat supported.</p>
    </div>

    <div class="toolbar">
      <div class="group">
        <label class="switch"><input type="checkbox" id="kb-toggle" /><span class="slider"></span></label>
        <span class="kb-status" id="kb-status">Knowledge base: off</span>
      </div>
      <div class="group">
        <button class="btn btn-ghost" onclick="uploadDoc()">📄 Upload Doc</button>
        <input type="file" id="doc-input" accept=".txt,.md,.json,.csv,.html,.text" style="display:none" onchange="doUploadDoc(event)" />
      </div>
      <div class="group">
        <button class="btn btn-ghost" onclick="document.getElementById('img-input').click()">🖼️ Attach Image</button>
        <input type="file" id="img-input" accept="image/*" style="display:none" onchange="addImage(event)" />
      </div>
      <div class="group">
        <button class="btn btn-secondary" onclick="refreshKb()">⟳ KB</button>
      </div>
    </div>

    <div class="thumbs" id="thumbs"></div>

    <div id="chat-container"></div>

    <div class="input-area">
      <textarea id="user-input" rows="2" placeholder="Type your message... (images are sent with your next message)"></textarea>
      <div class="row">
        <button class="btn btn-primary" onclick="sendMessage()">Send</button>
        <button class="btn btn-secondary" onclick="resetChat()">Reset</button>
        <span class="status" id="status">Ready</span>
      </div>
    </div>
  </div>

  <script>
    const OPENAI_API_KEY = "no";
    let currentModel = "unknown";
    let kbEnabled = false;
    let pendingImages = [];  // {name, dataUrl}

    window.onload = function () { refreshModels(); refreshKb(); };

    function setStatus(m){ document.getElementById("status").textContent = m; }

    async function refreshModels() {
      try {
        const r = await fetch("/v1/models", { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` } });
        const d = await r.json();
        currentModel = (d.data && d.data[0] && d.data[0].id) || "unknown";
      } catch (e) { console.warn(e); }
    }

    async function refreshKb() {
      try {
        const r = await fetch("/v1/kb/status", { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` } });
        const d = await r.json();
        const toggle = document.getElementById("kb-toggle");
        const status = document.getElementById("kb-status");
        if (!d.available) {
          toggle.disabled = true;
          status.textContent = "Knowledge base: unavailable (start server with --kb-embedding)";
          return;
        }
        kbEnabled = !!d.enabled;
        toggle.checked = kbEnabled;
        toggle.disabled = false;
        status.textContent = `Knowledge base: ${kbEnabled ? "ON" : "off"} · ${d.documents} docs · ${d.chunks} chunks`;
      } catch (e) { console.warn(e); }
    }

    document.getElementById("kb-toggle").addEventListener("change", async function () {
      const on = this.checked;
      try {
        await fetch("/v1/kb/toggle", {
          method: "POST", headers: { "Content-Type":"application/json", Authorization:`Bearer ${OPENAI_API_KEY}` },
          body: JSON.stringify({ enabled: on })
        });
        kbEnabled = on;
        document.getElementById("kb-status").textContent = `Knowledge base: ${on ? "ON" : "off"}`;
      } catch (e) { this.checked = !on; alert("Failed to toggle KB: " + e.message); }
    });

    function uploadDoc() { document.getElementById("doc-input").click(); }
    async function doUploadDoc(e) {
      const f = e.target.files[0];
      if (!f) return;
      const fd = new FormData();
      fd.append("file", f);
      setStatus("Uploading " + f.name + " ...");
      try {
        const r = await fetch("/v1/kb/upload", { method:"POST", body: fd });
        const d = await r.json();
        if (d.ok) { setStatus(`Indexed ${f.name}: ${d.chunks} chunks (total ${d.total_chunks})`); refreshKb(); }
        else setStatus("Upload failed: " + (d.error || "unknown"));
      } catch (err) { setStatus("Upload error: " + err.message); }
      e.target.value = "";
    }

    function addImage(e) {
      const f = e.target.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = function () {
        pendingImages.push({ name: f.name, dataUrl: reader.result });
        renderThumbs();
      };
      reader.readAsDataURL(f);
      e.target.value = "";
    }
    function renderThumbs() {
      const box = document.getElementById("thumbs");
      box.innerHTML = "";
      pendingImages.forEach((img, i) => {
        const d = document.createElement("div");
        d.className = "thumb";
        d.innerHTML = `<img src="${img.dataUrl}"/><button class="x" onclick="removeImage(${i})">×</button>`;
        box.appendChild(d);
      });
    }
    function removeImage(i) { pendingImages.splice(i, 1); renderThumbs(); }

    let messages = [{ role: "system", content: "You are a helpful assistant." }];

    async function resetChat() {
      messages = [{ role: "system", content: "You are a helpful assistant." }];
      document.getElementById("chat-container").innerHTML = "";
      pendingImages = []; renderThumbs();
      setStatus("Chat reset");
      try { await fetch("/reset", { method:"POST", headers:{ Authorization:`Bearer ${OPENAI_API_KEY}` }, body: JSON.stringify({reset:true}) }); } catch(e){}
    }

    async function sendMessage() {
      const input = document.getElementById("user-input");
      const text = input.value.trim();
      if (!text && pendingImages.length === 0) return;
      input.value = "";

      // Build the user message content (text + optional images).
      let userContent;
      if (pendingImages.length > 0) {
        userContent = [];
        if (text) userContent.push({ type: "text", text: text });
        for (const img of pendingImages) userContent.push({ type: "image_url", image_url: { url: img.dataUrl } });
      } else {
        userContent = text;
      }
      messages.push({ role: "user", content: userContent });
      displayMessage(text || "[image]", "user");
      if (pendingImages.length) showImageEcho(pendingImages);
      pendingImages = []; renderThumbs();
      setStatus("Thinking...");

      const payload = {
        model: currentModel,
        messages: messages,
        max_tokens: 100,
        temperature: 0.7,
        stream: true,
        knowledge_base: kbEnabled
      };

      try {
        const resp = await fetch("/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type":"application/json", Authorization:`Bearer ${OPENAI_API_KEY}`, Accept:"text/event-stream" },
          body: JSON.stringify(payload)
        });
        if (!resp.ok) throw new Error(`Error ${resp.status}`);
        await handleStream(resp);
      } catch (err) {
        displayMessage("Error: " + err.message, "assistant");
        setStatus("Error: " + err.message);
      }
    }

    async function handleStream(resp) {
      let acc = "";
      const chat = document.getElementById("chat-container");
      const el = document.createElement("div");
      el.className = "message assistant";
      el.innerHTML = `<strong>Assistant:</strong> <span></span>`;
      chat.appendChild(el); chat.scrollTop = chat.scrollHeight;
      const span = el.querySelector("span");
      const reader = resp.body.getReader();
      const dec = new TextDecoder("utf-8");
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          const chunk = dec.decode(value, { stream: true });
          for (const line of chunk.split("\n")) {
            if (!line.startsWith("data: ")) continue;
            const js = line.slice(6).trim();
            if (js === "[DONE]") { messages.push({ role:"assistant", content: acc }); setStatus("Done"); return; }
            try {
              const p = JSON.parse(js);
              const dc = p.choices && p.choices[0] && p.choices[0].delta && p.choices[0].delta.content;
              if (dc) { acc += dc; span.textContent = acc; chat.scrollTop = chat.scrollHeight; }
            } catch (e) {}
          }
        }
      } finally { reader.releaseLock(); }
    }

    function displayMessage(text, sender) {
      const chat = document.getElementById("chat-container");
      const el = document.createElement("div");
      el.className = "message " + sender;
      el.innerHTML = `<strong>${sender === "user" ? "User" : "Assistant"}:</strong> ${escapeHtml(text)}`;
      chat.appendChild(el); chat.scrollTop = chat.scrollHeight;
    }
    function showImageEcho(imgs) {
      const chat = document.getElementById("chat-container");
      const el = document.createElement("div");
      el.className = "message user";
      el.innerHTML = imgs.map(i => `<img src="${i.dataUrl}" style="height:60px;border-radius:6px;margin:.2rem"/>`).join("");
      chat.appendChild(el); chat.scrollTop = chat.scrollHeight;
    }
    function escapeHtml(s){ return (s||"").replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
  </script>
</body>
</html>
)""";

    // Start the HTTP server. `opt` carries the model + knowledge-base config.
    void Start(MNN::Transformer::Llm* llm, MnncliServerOptions opt);
    bool is_r1_{false};
  private:
    // Text path (existing behaviour, unchanged).
    void Answer(MNN::Transformer::Llm* llm, const json &messages, std::function<void(const std::string&)> on_result);
    void AnswerStreaming(MNN::Transformer::Llm* llm,
                         const json& messages,
                         std::function<void(const std::string&, bool end)> on_partial);

    // Multimodal (image) path: feed pre-tokenized ids that already include
    // vision embeddings, reusing the streaming <eop> protocol.
    void AnswerMultimodal(MNN::Transformer::Llm* llm, const std::vector<int>& input_ids,
                          std::function<void(const std::string&)> on_result);
    void AnswerMultimodalStreaming(MNN::Transformer::Llm* llm, const std::vector<int>& input_ids,
                                   std::function<void(const std::string&, bool end)> on_partial);

    // Helpers.
    static std::string decodeBase64(const std::string& in);
    static bool loadImageToVar(const std::string& src, MNN::Express::VARP& out);
    static std::vector<int> prepareMultimodalInputIds(MNN::Transformer::Llm* llm,
                                                      const json& messages,
                                                      MNN::Transformer::MultimodalPrompt& mp);
    static void saveUploadedText(KnowledgeBase& kb, const std::string& name, const std::string& text);

    std::mutex llm_mutex_;

    // Knowledge-base / vision state (set from MnncliServerOptions in Start()).
    bool vision_{false};
    std::shared_ptr<MNN::Transformer::Embedding> embedding_;
    std::unique_ptr<MnnEmbedder> embedder_;
    std::unique_ptr<KnowledgeBase> kb_;
    std::unique_ptr<MNN::Transformer::RerankerBase> reranker_model_;
    std::unique_ptr<MnnReranker> reranker_;
    std::string kb_dir_;
    size_t kb_top_k_ = 4;
};

}  // namespace mnncli
