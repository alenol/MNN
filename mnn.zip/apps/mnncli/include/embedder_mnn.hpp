//
//  embedder_mnn.hpp
//
//  Adapters that connect MNN's Embedding / Reranker engines to the
//  knowledge_base interfaces (Embedder / KbReranker).
//
//  Copyright (c) 2026 Alibaba Group Holding Limited. All rights reserved.
//

#pragma once

#include "knowledge_base.hpp"

namespace MNN {
namespace Transformer {
class Embedding;
class RerankerBase;
}  // namespace Transformer
}  // namespace MNN

namespace mnncli {

// Wraps an MNN Embedding model. Produces L2-normalized vectors so the
// knowledge base can use plain dot-product cosine similarity.
class MnnEmbedder : public Embedder {
public:
    explicit MnnEmbedder(MNN::Transformer::Embedding* embedding);
    std::vector<float> embed(const std::string& text) override;
    size_t dim() const override;

private:
    MNN::Transformer::Embedding* embedding_;
    mutable size_t dim_ = 0;
};

// Wraps an MNN reranker (Qwen3Reranker / GteReranker) for two-stage retrieval.
class MnnReranker : public KbReranker {
public:
    explicit MnnReranker(MNN::Transformer::RerankerBase* reranker);
    std::vector<float> score(const std::string& query,
                             const std::vector<std::string>& documents) override;

private:
    MNN::Transformer::RerankerBase* reranker_;
};

}  // namespace mnncli
