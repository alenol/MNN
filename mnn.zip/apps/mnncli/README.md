# MNNCLI

> Note: This project is under active development and may contain bugs or unfinished features. Use with caution.

MNNCLI is a command-line interface tool for MNN (Mobile Neural Network) that provides various functionalities for working with LLM models.

## Features

- **Model Management**: List, download, and delete models
- **Model Serving**: Start a web server to serve models via HTTP API
- **Model Execution**: Run models with prompts or prompt files
- **Benchmarking**: Performance benchmarking for models
- **Model Search**: Search for models in the Hugging Face repository
- **Local Knowledge Base (RAG)**: Build a local knowledge base from your documents and let the LLM retrieve answers from it. A runtime toggle turns retrieval on/off without restarting the server
- **Document & Image Upload**: Upload `.txt/.md/.json/.csv/.html` documents into the knowledge base from the web UI, and attach images to chat messages for multimodal (vision) models

## Building

To build MNNCLI, run the following commands from the mnncli directory:

```bash
sh build.sh
```

The executable will be located at `build_mnncli/mnncli`.

## Usage

### List Models
```bash
./build_mnncli/mnncli list
```

### Serve Model
```bash
./build_mnncli/mnncli serve <model_name>
```

Optional host/port:
```bash
./build_mnncli/mnncli serve <model_name> --host 127.0.0.1 --port 8000
```

### Serve with a Local Knowledge Base (RAG)

The knowledge base needs an **embedding model** (and optionally a **reranker**).
Pass `--kb-embedding <model>` to enable it; the server starts with retrieval ON and
you can flip the toggle in the web UI at any time.

```bash
# Text retrieval only
./build_mnncli/mnncli serve <llm_model> \
  --kb-embedding <embedding_model> \
  --kb-dir ~/.mnn_kb \
  --kb-chunk-size 512 --kb-top-k 4

# With a second-stage reranker (better ranking)
./build_mnncli/mnncli serve <llm_model> \
  --kb-embedding <embedding_model> \
  --kb-rerank <reranker_model> --kb-rerank-type qwen3   # or: gte

# Force the knowledge base off at startup (still toggleable later)
./build_mnncli/mnncli serve <llm_model> --kb-embedding <embedding_model> --kb-enable false
```

New `serve` flags:

| Flag | Meaning |
|------|---------|
| `--kb-embedding <model>` | Embedding model path; enables the knowledge base |
| `--kb-dir <dir>` | Directory for the persisted `kb.bin` index (default: in-memory only) |
| `--kb-enable <bool>` | Initial toggle state (default `true` when an embedding model is set) |
| `--kb-chunk-size <n>` | Chunk size in characters (default `512`) |
| `--kb-top-k <n>` | Number of chunks retrieved per query (default `4`) |
| `--kb-rerank <model>` | Optional reranker model path (Qwen3/Gte) |
| `--kb-rerank-type <qwen3\|gte>` | Reranker implementation (default `qwen3`) |
| `--vision` | Mark the served model as multimodal/vision-capable (image chat) |

In the web UI you can:
- flip the **Knowledge base** switch (calls `POST /v1/kb/toggle`),
- click **📄 Upload Doc** to index a document (`POST /v1/kb/upload`),
- click **🖼️ Attach Image** to attach an image to your next message.

Images are sent as OpenAI-style `image_url` content parts and are forwarded to
vision models automatically (requires the server to be built with the vision
build flag and started with `--vision`).

Knowledge-base HTTP endpoints:

| Endpoint | Method | Purpose |
|---------|--------|---------|
| `/v1/kb/status` | GET | `available`, `enabled`, doc/chunk counts, `vision` |
| `/v1/kb/documents` | GET / DELETE | List or clear indexed documents |
| `/v1/kb/upload` | POST | Upload & index a document (multipart or JSON) |
| `/v1/kb/toggle` | POST | Enable/disable retrieval `{"enabled": bool}` |
| `/v1/kb/search` | POST | Raw retrieval `{"query": "...", "top_k": n}` |

During chat, retrieval is also controllable per-request via
`"knowledge_base": true/false` and `"kb_top_k": n`, and reranking via
`"kb_rerank": true` (when a reranker is configured).

> **Build note (image chat):** image upload reuses MNN's `MNN::CV::imread`
> (compiled into libMNN when built with `MNN_BUILD_LLM_OMNI=ON`). Enable it in
> the mnncli build with `-DMNNCLI_VISION=ON` (the bundled `build.sh` does this by
> default). Without it, the server compiles and runs but returns a graceful error
> if an image is attached.

### Run Model
```bash
./build_mnncli/mnncli run <model_name> [-c config_path] [-p prompt] [-f prompt_file]
```

### Benchmark Model
```bash
./build_mnncli/mnncli benchmark <model_name> [-c config_path]
```

### Download Model
```bash
./build_mnncli/mnncli download <model_name> <repo_name>
```

### Search Models
```bash
./build_mnncli/mnncli search <keyword>
```

### Delete Model
```bash
./build_mnncli/mnncli delete <model_name>
```

## HTTP API Compatibility

### `mnncli serve` (OpenAI-compatible)

Available endpoints:
- `GET /v1/models`
- `POST /v1/chat/completions`
- `POST /chat/completions` (alias)

Minimal `curl` examples:

```bash
curl http://127.0.0.1:8000/v1/models
```

```bash
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen3.5-0.8B-MNN",
    "messages": [{"role": "user", "content": "Hello"}],
    "stream": false
  }'
```


### Anthropic-compatible (`/v1/messages`)

Available endpoint:
- `POST /v1/messages`

Minimal `curl` example:

```bash
curl http://127.0.0.1:8000/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: dummy" \
  -d '{
    "model": "Qwen3.5-0.8B-MNN",
    "max_tokens": 128,
    "messages": [{
      "role": "user",
      "content": [{"type": "text", "text": "Hello"}]
    }]
  }'
```

This route is designed for Anthropic-style clients (including Claude-compatible integrations) and supports both non-stream and stream requests.
## Dependencies

- OpenSSL (for HTTPS support)
- MNN core library
- LLM engine library

## Notes

- The tool requires macOS 13.0+ when building on Apple platforms
- On Linux, ensure `libssl-dev` (or equivalent) is installed
- Models are cached in the user's cache directory
- `mnncli serve` currently provides OpenAI-compatible and Anthropic-compatible API routes
