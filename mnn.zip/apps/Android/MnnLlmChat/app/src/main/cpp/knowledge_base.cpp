//
// knowledge_base.cpp — local RAG store for MnnLlmChat (Android).
// Embeddings come from the chat Llm (tokenizer_encode + Llm::embedding).
//
// Copyright (c) 2026 Alibaba Group Holding Limited All rights reserved.
//

#include "knowledge_base.h"

#include <MNN/expr/Expr.hpp>
#include <llm/llm.hpp>

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <sstream>

namespace mls {

// ---- CJK-aware chunk splitting (so Chinese docs don't break mid-character) ----
static bool isCjkBreak(const std::string& text, size_t pos) {
    if (pos == 0 || pos >= text.size()) return true;
    unsigned char c = static_cast<unsigned char>(text[pos]);
    unsigned char pc = static_cast<unsigned char>(text[pos - 1]);
    // Break between ASCII and non-ASCII boundaries, or on whitespace.
    bool curCjk = (c >= 0x80);
    bool prevCjk = (pc >= 0x80);
    if (curCjk != prevCjk) return true;
    if (std::isspace(static_cast<unsigned char>(text[pos])) &&
        !std::isspace(static_cast<unsigned char>(text[pos - 1])))
        return true;
    return false;
}

static size_t findBreak(const std::string& text, size_t start, size_t hint) {
    size_t lo = start + std::max<size_t>(1, hint / 2);
    size_t br = hint;
    for (size_t i = hint; i > lo && i > start; --i) {
        if (isCjkBreak(text, i)) { br = i; break; }
    }
    if (br <= start) br = hint;
    return br;
}

// ---- tiny binary serialization helpers ----
static void writeU32(std::ostream& os, uint32_t v) {
    os.write(reinterpret_cast<const char*>(&v), sizeof(v));
}
static void writeStr(std::ostream& os, const std::string& s) {
    uint32_t n = static_cast<uint32_t>(s.size());
    writeU32(os, n);
    if (!s.empty()) os.write(s.data(), static_cast<std::streamsize>(s.size()));
}
static bool readU32(std::istream& is, uint32_t& v) {
    return static_cast<bool>(is.read(reinterpret_cast<char*>(&v), sizeof(v)));
}
static bool readStr(std::istream& is, std::string& s) {
    uint32_t n = 0;
    if (!readU32(is, n)) return false;
    s.resize(n);
    if (n > 0) is.read(&s[0], static_cast<std::streamsize>(n));
    return static_cast<bool>(is);
}

KnowledgeBase::KnowledgeBase(MNN::Transformer::Llm* llm) : llm_(llm) {}

std::vector<std::string> KnowledgeBase::splitIntoChunks(const std::string& text,
                                                        size_t chunk_size,
                                                        size_t overlap) const {
    std::vector<std::string> chunks;
    if (text.empty()) return chunks;
    size_t start = 0;
    const size_t n = text.size();
    while (start < n) {
        size_t end = std::min(start + chunk_size, n);
        if (end < n) end = findBreak(text, start, end);
        if (end <= start) end = std::min(start + chunk_size, n);
        chunks.emplace_back(text.substr(start, end - start));
        if (end >= n) break;
        size_t next = (end > overlap) ? end - overlap : end;
        if (next <= start) next = end;
        start = next;
    }
    return chunks;
}

float KnowledgeBase::cosine(const std::vector<float>& a, const std::vector<float>& b) {
    if (a.empty() || b.empty() || a.size() != b.size()) return 0.0f;
    double dot = 0.0;
    double na = 0.0, nb = 0.0;
    for (size_t i = 0; i < a.size(); ++i) {
        dot += static_cast<double>(a[i]) * b[i];
        na += static_cast<double>(a[i]) * a[i];
        nb += static_cast<double>(b[i]) * b[i];
    }
    if (na <= 0.0 || nb <= 0.0) return 0.0f;
    return static_cast<float>(dot / (std::sqrt(na) * std::sqrt(nb)));
}

std::vector<float> KnowledgeBase::embed(const std::string& text) const {
    std::vector<float> out;
    if (!llm_) return out;
    std::vector<int> ids = llm_->tokenizer_encode(text);
    if (ids.empty()) return out;
    auto var = llm_->embedding(ids);
    if (var == nullptr) return out;
    auto ptr = var->readMap<float>();
    const size_t n = static_cast<size_t>(var->getInfo()->size);
    out.assign(ptr, ptr + n);
    if (dim_ == 0) dim_ = n;
    // L2-normalize so cosine == dot product.
    double norm = 0.0;
    for (float v : out) norm += static_cast<double>(v) * v;
    norm = std::sqrt(norm);
    if (norm > 0.0) {
        const float inv = static_cast<float>(1.0 / norm);
        for (float& v : out) v *= inv;
    }
    return out;
}

void KnowledgeBase::addDocument(const std::string& name, const std::string& text) {
    std::vector<std::string> parts = splitIntoChunks(text, chunk_size_, overlap_);
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& part : parts) {
            KbChunk chunk;
            chunk.doc = name;
            chunk.text = part;
            if (llm_) {
                chunk.vector = embed(part);
            }
            chunks_.push_back(std::move(chunk));
        }
        bool found = false;
        for (auto& d : doc_names_) { if (d == name) { found = true; break; } }
        if (!found) doc_names_.push_back(name);
        // Keep original text for view/replace; preserve existing enabled flag.
        doc_text_[name] = text;
        auto it = doc_enabled_.find(name);
        if (it == doc_enabled_.end()) doc_enabled_[name] = true;
    }
}

void KnowledgeBase::addText(const std::string& text) {
    std::string name = "paste-" + std::to_string(++counter_);
    addDocument(name, text);
}

bool KnowledgeBase::removeDocument(const std::string& name) {
    std::lock_guard<std::mutex> lock(mutex_);
    const size_t before = chunks_.size();
    std::vector<KbChunk> kept;
    kept.reserve(chunks_.size());
    for (auto& c : chunks_) {
        if (c.doc != name) kept.push_back(std::move(c));
    }
    chunks_.swap(kept);
    if (chunks_.size() != before) {
        // Remove the doc name from the index if no chunks remain for it.
        std::vector<std::string> names;
        names.reserve(doc_names_.size());
        for (auto& d : doc_names_) {
            if (d != name) names.push_back(std::move(d));
        }
        doc_names_.swap(names);
        doc_enabled_.erase(name);
        doc_text_.erase(name);
        return true;
    }
    return false;
}

std::vector<KbChunk> KnowledgeBase::retrieve(const std::string& query,
                                             size_t top_k) const {
    if (!enabled_ || query.empty() || !llm_ || top_k == 0) return {};
    std::vector<float> qvec = embed(query);
    if (qvec.empty()) return {};
    std::lock_guard<std::mutex> lock(mutex_);
    struct Scored { size_t idx; float score; };
    std::vector<Scored> scored;
    scored.reserve(chunks_.size());
    for (size_t i = 0; i < chunks_.size(); ++i) {
        if (chunks_[i].vector.empty()) continue;
        // Skip chunks whose document is disabled from retrieval.
        auto eit = doc_enabled_.find(chunks_[i].doc);
        if (eit != doc_enabled_.end() && !eit->second) continue;
        scored.push_back({i, cosine(qvec, chunks_[i].vector)});
    }
    std::sort(scored.begin(), scored.end(),
              [](const Scored& a, const Scored& b) { return a.score > b.score; });
    std::vector<KbChunk> out;
    for (size_t i = 0; i < scored.size() && i < top_k; ++i) {
        out.push_back(chunks_[scored[i].idx]);
    }
    return out;
}

std::string KnowledgeBase::buildContext(const std::string& query, size_t top_k) const {
    auto hits = retrieve(query, top_k);
    if (hits.empty()) return "";
    std::ostringstream os;
    os << "\n以下是与用户问题相关的本地知识库参考内容：\n";
    int i = 1;
    for (const auto& h : hits) {
        os << "[" << i++ << "] (" << h.doc << ")\n" << h.text << "\n\n";
    }
    return os.str();
}

size_t KnowledgeBase::docCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return doc_names_.size();
}
size_t KnowledgeBase::chunkCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return chunks_.size();
}
std::vector<std::string> KnowledgeBase::docNames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return doc_names_;
}

bool KnowledgeBase::docEnabled(const std::string& name) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = doc_enabled_.find(name);
    return it == doc_enabled_.end() || it->second;
}
void KnowledgeBase::setDocEnabled(const std::string& name, bool on) {
    std::lock_guard<std::mutex> lock(mutex_);
    doc_enabled_[name] = on;
}
std::string KnowledgeBase::docText(const std::string& name) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = doc_text_.find(name);
    return it == doc_text_.end() ? std::string() : it->second;
}

void KnowledgeBase::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    chunks_.clear();
    doc_names_.clear();
    doc_enabled_.clear();
    doc_text_.clear();
    counter_ = 0;
}

bool KnowledgeBase::save(const std::string& path) const {
    std::ofstream os(path, std::ios::binary);
    if (!os) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    writeU32(os, static_cast<uint32_t>(chunk_size_));
    writeU32(os, static_cast<uint32_t>(overlap_));
    writeU32(os, 2u);  // version 2: adds per-doc enabled flag + original text
    writeU32(os, static_cast<uint32_t>(doc_names_.size()));
    for (const auto& d : doc_names_) {
        writeStr(os, d);
        // enabled flag (1/0) and original text for each doc.
        auto eit = doc_enabled_.find(d);
        writeU32(os, (eit != doc_enabled_.end() && eit->second) ? 1u : 0u);
        auto tit = doc_text_.find(d);
        writeStr(os, tit != doc_text_.end() ? tit->second : std::string());
    }
    writeU32(os, static_cast<uint32_t>(chunks_.size()));
    for (const auto& c : chunks_) {
        writeStr(os, c.doc);
        writeStr(os, c.text);
        writeU32(os, static_cast<uint32_t>(c.vector.size()));
        if (!c.vector.empty())
            os.write(reinterpret_cast<const char*>(c.vector.data()),
                     static_cast<std::streamsize>(c.vector.size() * sizeof(float)));
    }
    return static_cast<bool>(os);
}

bool KnowledgeBase::load(const std::string& path) {
    std::ifstream is(path, std::ios::binary);
    if (!is) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    uint32_t cs = 0, ov = 0, ver = 0, nd = 0, nc = 0;
    if (!readU32(is, cs) || !readU32(is, ov) || !readU32(is, ver)) return false;
    chunk_size_ = cs; overlap_ = ov;
    if (!readU32(is, nd)) return false;
    doc_names_.clear();
    doc_enabled_.clear();
    doc_text_.clear();
    for (uint32_t i = 0; i < nd; ++i) {
        std::string d; if (!readStr(is, d)) return false; doc_names_.push_back(d);
        if (ver >= 2u) {
            uint32_t en = 0; if (!readU32(is, en)) return false;
            doc_enabled_[d] = (en != 0u);
            std::string txt; if (!readStr(is, txt)) return false;
            doc_text_[d] = txt;
        } else {
            doc_enabled_[d] = true;
        }
    }
    if (!readU32(is, nc)) return false;
    chunks_.clear();
    for (uint32_t i = 0; i < nc; ++i) {
        KbChunk c;
        if (!readStr(is, c.doc) || !readStr(is, c.text)) return false;
        uint32_t vs = 0; if (!readU32(is, vs)) return false;
        c.vector.resize(vs);
        if (vs > 0) is.read(reinterpret_cast<char*>(c.vector.data()),
                            static_cast<std::streamsize>(vs * sizeof(float)));
        chunks_.push_back(std::move(c));
    }
    return static_cast<bool>(is);
}

}  // namespace mls
