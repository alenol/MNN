//
// knowledge_base.h — local RAG (retrieval-augmented generation) for the
// MnnLlmChat Android app. Embeddings are produced by the SAME Llm instance
// that powers the chat (Llm::embedding over tokenizer_encode(text)), so no
// separate embedding model download is required.
//
// Copyright (c) 2026 Alibaba Group Holding Limited All rights reserved.
//

#pragma once

#include <string>
#include <vector>
#include <mutex>
#include <memory>

namespace MNN {
namespace Transformer {
class Llm;
}  // namespace Transformer
}  // namespace MNN

namespace mls {

struct KbChunk {
    std::string doc;
    std::string text;
    std::vector<float> vector;
};

// A small in-memory vector store with cosine (dot-product after L2 norm)
// similarity retrieval. Documents are split into overlapping chunks, each
// chunk is embedded with the chat Llm, and queries retrieve the top-k chunks.
class KnowledgeBase {
public:
    explicit KnowledgeBase(MNN::Transformer::Llm* llm);
    ~KnowledgeBase() = default;

    void setChunkSize(size_t bytes) { chunk_size_ = bytes; }
    void setOverlap(size_t bytes) { overlap_ = bytes; }
    void setEnabled(bool on) { enabled_ = on; }
    bool enabled() const { return enabled_; }

    // Add a named document (plain text). Splits into chunks and embeds each.
    void addDocument(const std::string& name, const std::string& text);
    // Add ad-hoc pasted text.
    void addText(const std::string& text);

    // Retrieve the top-k most relevant chunks for a query. Returns empty when
    // disabled or no embedder / documents.
    std::vector<KbChunk> retrieve(const std::string& query, size_t top_k) const;

    // Format retrieved chunks into a context block for prompt injection.
    std::string buildContext(const std::string& query, size_t top_k) const;

    size_t docCount() const;
    size_t chunkCount() const;
    std::vector<std::string> docNames() const;

    void clear();
    bool save(const std::string& path) const;
    bool load(const std::string& path);

private:
    std::vector<std::string> splitIntoChunks(const std::string& text,
                                             size_t chunk_size,
                                             size_t overlap) const;
    std::vector<float> embed(const std::string& text) const;
    static float cosine(const std::vector<float>& a, const std::vector<float>& b);

    MNN::Transformer::Llm* llm_;
    mutable std::mutex mutex_;
    std::vector<KbChunk> chunks_;
    std::vector<std::string> doc_names_;
    size_t chunk_size_ = 512;
    size_t overlap_ = 64;
    bool enabled_ = false;
    mutable size_t dim_ = 0;
    long counter_ = 0;
};

}  // namespace mls
