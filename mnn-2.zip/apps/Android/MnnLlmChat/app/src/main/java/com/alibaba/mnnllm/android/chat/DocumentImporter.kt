package com.alibaba.mnnllm.android.chat

import android.content.ContentResolver
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.util.zip.Inflater
import java.util.zip.ZipInputStream
import kotlin.text.RegexOption

/**
 * 纯 JDK 实现的本地文档文本提取器（不引入任何第三方解析库，避免构建体积与兼容风险）。
 *
 * 支持：
 *  - 纯文本 / 代码类（txt, md, csv, sh, bat, py, json, xml, log, 源码 ...）：直接按文本读取。
 *  - Office Open XML（docx / xlsx / pptx）：解 ZIP 后解析 XML 抽取文本。
 *  - PDF：尽力而为的文本提取（含 FlateDecode 流解压）。
 *  - 旧版 Office（doc / ppt / xls）：尽力而为地抽取可读片段。
 *
 * 同时提供 [needsVision] 用于判断某扩展名是否属于“需要视觉模型才能正确分析”的文档类型。
 */
object DocumentImporter {

    /** 纯文本 / 代码类，直接读取即可。 */
    private val TEXT_EXTS = setOf(
        "txt", "text", "md", "markdown", "csv", "tsv", "sh", "bat", "cmd", "py", "pyw",
        "json", "jsonl", "xml", "html", "htm", "log", "yaml", "yml", "ini", "conf", "cfg",
        "c", "h", "cpp", "cc", "cxx", "hpp", "hxx", "java", "kt", "kts", "js", "mjs", "ts",
        "jsx", "tsx", "go", "rs", "rb", "php", "pl", "pm", "lua", "sql", "r", "swift",
        "scala", "vim", "tex", "properties", "toml", "gradle", "ps1", "psm1", "gitignore",
        "dockerfile", "cmake", "makefile"
    )

    private val OOXML_TEXT_EXTS = setOf("docx")
    private val OOXML_SHEET_EXTS = setOf("xlsx")
    private val OOXML_SLIDE_EXTS = setOf("pptx")

    /** 需要视觉模型才能正确分析的文档类型（如演示文稿、PDF 等图文型文档）。 */
    val VISION_REQUIRED_EXTS = setOf("ppt", "pptx", "pdf", "key", "odp", "rtf")

    /** 旧版二进制 Office（尽力提取，效果有限）。 */
    private val LEGACY_EXTS = setOf("doc", "ppt", "xls")

    private const val MAX_READ_BYTES = 16 * 1024 * 1024

    data class Result(val text: String, val note: String?, val truncated: Boolean)

    /** 该扩展名是否属于“需要视觉模型”的文档类型。 */
    fun needsVision(ext: String): Boolean = VISION_REQUIRED_EXTS.contains(ext.lowercase())

    /** 根据扩展名提取文档文本；无法读取返回 null。 */
    fun extractText(resolver: ContentResolver, uri: Uri, displayName: String): Result? {
        val ext = displayName.substringAfterLast('.', "").lowercase()
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val truncated = bytes.size > MAX_READ_BYTES
        val data = if (truncated) bytes.copyOf(MAX_READ_BYTES) else bytes
        return when {
            TEXT_EXTS.contains(ext) -> parsePlain(data, truncated)
            OOXML_TEXT_EXTS.contains(ext) -> parseDocx(data, truncated)
            OOXML_SHEET_EXTS.contains(ext) -> parseXlsx(data, truncated)
            OOXML_SLIDE_EXTS.contains(ext) -> parsePptx(data, truncated)
            ext == "pdf" -> parsePdf(data, truncated)
            LEGACY_EXTS.contains(ext) -> parseLegacy(data, ext, truncated)
            else -> parsePlain(data, truncated)
        }
    }

    // ---------------------------------------------------------------- 纯文本
    private fun parsePlain(data: ByteArray, truncated: Boolean): Result {
        return Result(decodeText(data),
            if (truncated) "文件较大，仅提取了前 ${MAX_READ_BYTES / (1024 * 1024)}MB" else null,
            truncated)
    }

    private fun decodeText(data: ByteArray): String {
        val utf8 = String(data, Charsets.UTF_8)
        // 若 UTF-8 解码出现大量替换字符，多半是 GBK/GB18030 中文文件，回退尝试。
        return if (utf8.count { it == '\uFFFD' } * 20 < data.size) {
            utf8
        } else {
            try { String(data, Charset.forName("GB18030")) } catch (e: Exception) { utf8 }
        }
    }

    // ---------------------------------------------------------------- docx
    private fun parseDocx(data: ByteArray, truncated: Boolean): Result {
        val xml = firstEntry(data, "word/document.xml")
            ?: return Result("", "未找到 word/document.xml", truncated)
        return Result(extractTags(xml, "<w:t", "</w:t>"),
            if (truncated) "文件较大，仅提取了部分内容" else null, truncated)
    }

    // ---------------------------------------------------------------- pptx
    private fun parsePptx(data: ByteArray, truncated: Boolean): Result {
        val sb = StringBuilder()
        forEachEntry(data) { name, content ->
            val m = Regex("ppt/slides/slide(\\d+)\\.xml").find(name)
            if (m != null) {
                sb.append("【幻灯片 ${m.groupValues[1]}】\n")
                sb.append(extractTags(content, "<a:t", "</a:t>")).append('\n')
            }
        }
        return Result(sb.toString(),
            if (truncated) "文件较大，仅提取了部分内容" else null, truncated)
    }

    // ---------------------------------------------------------------- xlsx
    private fun parseXlsx(data: ByteArray, truncated: Boolean): Result {
        val sharedXml = firstEntry(data, "xl/sharedStrings.xml")
        val sheetXml = firstEntry(data, "xl/worksheets/sheet1.xml")
            ?: return Result("", "未找到工作表", truncated)
        val strings = if (sharedXml != null) parseSharedStrings(sharedXml) else emptyList()
        return Result(parseSheet(sheetXml, strings),
            if (truncated) "文件较大，仅提取了部分内容" else null, truncated)
    }

    private fun parseSharedStrings(xml: String): List<String> {
        return Regex("<si>([\\s\\S]*?)</si>").findAll(xml).map { si ->
            extractTags(si.groupValues[1], "<t", "</t>").replace("\n", "")
        }.toList()
    }

    private fun parseSheet(xml: String, strings: List<String>): String {
        val rowPat = Regex("<row\\b[^>]*>([\\s\\S]*?)</row>")
        val block: (String) -> String = { parseCells(it, strings) }
        return if (rowPat.containsMatchIn(xml)) {
            rowPat.findAll(xml).joinToString("\n") { block(it.groupValues[1]).trimEnd('\t') }
        } else {
            block(xml).trimEnd('\t')
        }
    }

    private fun parseCells(block: String, strings: List<String>): String {
        val sb = StringBuilder()
        val cellPat = Regex("<c\\b([\\s\\S]*?)>([\\s\\S]*?)</c>")
        for (m in cellPat.findAll(block)) {
            val attrs = m.groupValues[1]
            val body = m.groupValues[2]
            val v = Regex("<v>([\\s\\S]*?)</v>").find(body)?.groupValues?.get(1)?.trim()
            val isInline = Regex("<is>([\\s\\S]*?)</is>").find(body)
            val tAttr = Regex("t=\"([^\"]*)\"").find(attrs)?.groupValues?.get(1)
            val text = when {
                tAttr == "s" && v != null -> {
                    val idx = v.toIntOrNull() ?: -1
                    if (idx in strings.indices) strings[idx] else ""
                }
                isInline != null -> extractTags(isInline.groupValues[1], "<t", "</t>").replace("\n", "")
                v != null -> v
                else -> ""
            }
            if (text.isNotEmpty()) sb.append(text).append('\t')
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- OOXML 通用
    private fun firstEntry(data: ByteArray, target: String): String? {
        var found: String? = null
        forEachEntry(data) { name, content -> if (name == target && found == null) found = content }
        return found
    }

    private fun forEachEntry(data: ByteArray, block: (String, String) -> Unit) {
        val zis = ZipInputStream(ByteArrayInputStream(data))
        val buf = ByteArray(8192)
        while (true) {
            val entry = zis.nextEntry ?: break
            val content = if (entry.name.endsWith(".xml")) {
                try { zis.bufferedReader().readText() } catch (e: Exception) { "" }
            } else {
                while (zis.read(buf) != -1) { }  // 耗尽该 entry，避免影响后续遍历
                ""
            }
            block(entry.name, content)
        }
        zis.close()
    }

    private fun extractTags(xml: String, openPrefix: String, close: String): String {
        val openPat = Regex(Regex.escape(openPrefix) + "[^>]*>", RegexOption.DOTALL)
        val sb = StringBuilder()
        var i = 0
        while (i < xml.length) {
            val m = openPat.find(xml, i) ?: break
            val start = m.range.last + 1
            val end = xml.indexOf(close, start)
            if (end < 0) break
            sb.append(unescapeXml(xml.substring(start, end))).append('\n')
            i = end + close.length
        }
        return sb.toString()
    }

    // ---------------------------------------------------------------- PDF（尽力而为）
    private fun parsePdf(data: ByteArray, truncated: Boolean): Result {
        val raw = String(data, Charsets.ISO_8859_1)
        val sb = StringBuilder()
        extractPdfOps(raw, sb)
        val streamPat = Regex("(?i)stream\r?\n(.*?)\r?\nendstream", RegexOption.DOTALL)
        for (m in streamPat.findAll(raw)) {
            if (!looksFlate(raw, m.range.first)) continue
            val block = m.groupValues[1].toByteArray(Charsets.ISO_8859_1)
            val inflated = inflate(block) ?: continue
            extractPdfOps(String(inflated, Charsets.ISO_8859_1), sb)
        }
        val text = sb.toString().replace(Regex("[ \t]+\n"), "\n").trim()
        val note = if (text.isEmpty())
            "PDF 文本提取有限（可能为扫描件 / 图片型，需用视觉模型分析）" else null
        return Result(text, note, truncated)
    }

    private fun extractPdfOps(s: String, sb: StringBuilder) {
        val tj = Regex("""(?<!\\\\)\(((?:\\.|[^\\()])*)\)\s*Tj""")
        for (m in tj.findAll(s)) sb.append(decodePdfString(m.groupValues[1])).append(' ')
        val tja = Regex("""\[((?:\\.|[^\\\[\]])*)\]\s*TJ""")
        for (m in tja.findAll(s)) {
            val inner = m.groupValues[1]
            val parts = Regex("""\(((?:\\.|[^\\()])*)\)|<([0-9a-fA-F\s]*)>""").findAll(inner)
            for (p in parts) {
                sb.append(
                    if (p.groupValues[1].isNotEmpty()) decodePdfString(p.groupValues[1])
                    else decodePdfHex(p.groupValues[2])
                ).append(' ')
            }
        }
    }

    private fun decodePdfString(raw: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < raw.length) {
            val c = raw[i]
            if (c == '\\') {
                i++
                if (i >= raw.length) break
                when (val n = raw[i]) {
                    'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                    'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                    '(', ')' -> sb.append(n); '\\' -> sb.append('\\')
                    in '0'..'7' -> {
                        var oct = ""; var j = i
                        while (j < raw.length && raw[j] in '0'..'7' && oct.length < 3) { oct += raw[j]; j++ }
                        i = j - 1
                        sb.append(oct.toIntOrNull(8)?.toChar() ?: '?')
                    }
                    else -> sb.append(n)
                }
            } else sb.append(c)
            i++
        }
        return sb.toString()
    }

    private fun decodePdfHex(hex: String): String {
        val clean = hex.replace("\\s".toRegex(), "")
        val sb = StringBuilder()
        var i = 0
        while (i + 1 < clean.length) {
            sb.append((clean.substring(i, i + 2).toIntOrNull(16) ?: 0).toChar())
            i += 2
        }
        return sb.toString()
    }

    private fun looksFlate(raw: String, pos: Int): Boolean {
        val start = (pos - 400).coerceAtLeast(0)
        return raw.substring(start, pos).contains("/FlateDecode", ignoreCase = true)
    }

    private fun inflate(block: ByteArray): ByteArray? {
        return try {
            val inf = Inflater(false)
            inf.setInput(block)
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0) { if (inf.needsInput() || inf.needsDictionary()) break }
                out.write(buf, 0, n)
            }
            inf.end()
            out.toByteArray()
        } catch (e: Exception) { null }
    }

    // ---------------------------------------------------------------- 旧版 Office
    private fun parseLegacy(data: ByteArray, ext: String, truncated: Boolean): Result {
        val s = String(data, Charsets.ISO_8859_1)
        val runs = Regex("[\\x20-\\x7e\\u4e00-\\u9fff\\uff00-\\uffef]{4,}").findAll(s).map { it.value }
        val text = runs.joinToString("\n")
        val note = if (text.isBlank())
            "无法从旧版 $ext 提取文本（建议另存为 docx / xlsx / pptx 后重试）"
        else "旧版 $ext 格式，文本提取有限，建议另存为新版格式"
        return Result(text, note, truncated)
    }

    private fun unescapeXml(s: String): String {
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&apos;", "'")
            .replace(Regex("&#x([0-9a-fA-F]+);")) {
                it.groupValues[1].toIntOrNull(16)?.toChar()?.toString() ?: it.value
            }
            .replace(Regex("&#(\\d+);")) {
                it.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: it.value
            }
    }
}
